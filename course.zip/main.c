/**
 * @mainpage course and student function demonstration
 *  
 * The course and student function demonstration shows how the multiple functions in the course and student 
 * libraries work, including:
 * - finding students average grade
 * - printing a library of a student
 * - generating an random student
 * - enrolling a student into a course
 * - printing a course and all of its students and the students information
 * - finding the student with the highest average
 * - creating a library of all passing students
 * 
 * @file main.c
 * @author Sharmin Ahmed 
 * @date 2022-04-10
 * @brief Runs demonstration code for the student and course library methods.
 * 
 */ 
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"


/**
 * Creates a library of courses represented as an array, creates another
 * library of students with 8 grades. and test the library methods for enrolling, 
 * randomly generating students, finding the top student, printing the student,
 * creating a library of total passsing students, and printing the course
 * 
 * 
 * 
 * 
 */
int main()
{
  srand((unsigned) time(NULL));
  
  // creates a library of courses
  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  // creates a library of students by randomly generating them
  // enrolls all the students into the course
  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  //prints course
  print_course(MATH101);
  // finds the student with highest grade average
  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);
  // creates a library of students passing
  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  // prints passing students
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}