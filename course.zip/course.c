/**
 * @file student.h
 * @author Sharmin Ahmed 
 * @date 2022-04-10
 * @brief course library for managing courses, including important information about courses and
 *        related function.
 *
 */


#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/** 
 * increases the amount of students in the class, and adds that student to the list of students
 * 
 * if the total amount of students is one, then i allocates memory for the student type
 * if there is more then one student, it realocated memory, to hold more student types
 * 
 * @param course is a Course type pointer, that keeps track of the class, and its details
 * @param student a student pointer, keeps track of the student, and their information
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}


/** 
 * Prints course and all of its information including: course name, course code, total students
 * and all the students and the students information
 * 
 * @param course is a Course type pointer, that keeps track of the class, and its details
 * @return nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}


/** 
 * returns the student with the highest average
 * 
 * @param course is a Course type pointer, that keeps track of the class, and its details
 * @return a student pointer
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}


/** 
 * returns an pointer, pointing to an array of all the students who have passed the course; with marks over 50
 * 
 * @param course is a Course type pointer, that keeps track of the class, and its details
 * @param total_passing is a pointer to am integer that holds the total amount of students passing this course
 * @return a student pointer of passing students pointer
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}