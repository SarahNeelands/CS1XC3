
/**
 * @file student.h
 * @author Sharmin Ahmed 
 * @date 2022-04-10
 * @brief Student library for managing students, including important information about students and
 *        related function.
 *
 */


/**
* student type that stores their first name, last name, id and grades
*
*/
typedef struct _student 
{ 
  char first_name[50]; /**< students first name */
  char last_name[50];/**< students last name */
  char id[11];/**< students id */
  double *grades; /**< the students has grades */
  int num_grades; /**< the amount of grades the students has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
