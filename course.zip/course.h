/**
 * @file student.h
 * @author Sharmin Ahmed 
 * @date 2022-04-10
 * @brief course library for managing courses, including important information about courses and
 *        related function.
 *
 */


#include "student.h"
#include <stdbool.h>


/**
* course type stores a course with the fields: name, code, students, and total students
*
*/

typedef struct _course 
{
  char name[100];/**< the courses name */
  char code[10];/**< the courses code*/
  Student *students;/**< the courses students, and their information*/
  int total_students;/**< the courses total amount of students */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


